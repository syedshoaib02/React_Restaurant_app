import React from 'react'

function Gallery() {
  return (
    <div className='App '>
      <h1>Gallery Page</h1></div>
  )
}

export default Gallery