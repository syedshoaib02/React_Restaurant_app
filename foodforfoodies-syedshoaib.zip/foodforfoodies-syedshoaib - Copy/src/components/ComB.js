import React from 'react'
import { ComC } from './ComC'

export const ComB = () => {
  return <ComC />
}
